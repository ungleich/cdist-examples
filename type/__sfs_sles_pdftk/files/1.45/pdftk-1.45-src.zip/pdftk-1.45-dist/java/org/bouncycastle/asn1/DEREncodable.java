package org.bouncycastle.asn1;

public interface DEREncodable
{
    public DERObject getDERObject();
}
